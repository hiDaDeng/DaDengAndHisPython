# -*- coding: utf-8 -*-

import pandas as pd
import jieba
import matplotlib.pyplot as plt
import seaborn as sns
from pylab import mpl
import pylab as pl
mpl.rcParams['font.sans-serif'] = ['SimHei'] # 指定默认字体
mpl.rcParams['axes.unicode_minus']


data = pd.read_excel('咪蒙阅读数据.xlsx',sheet_name = 0)
data = data[data['赞赏']!=-2]

#计算平均点赞数
data1 = data.sort_values(by='点赞',ascending=False)
print('最大点赞数',round(data1['点赞'].max(),0))
print('最小点赞数',round(data1['点赞'].min(),0))
print('平均点赞数',round(data1['点赞'].mean(),0))


#计算每年点赞量
data1['year'] = data1['发文时间'].dt.year
data_year =data1.groupby('year').sum()['点赞'].to_frame()
fig = plt.figure(figsize=(15,8))
x = data_year.index.tolist()
y = data_year['点赞'].tolist()
sns.barplot(x, y, palette="nipy_spectral_r")

plt.title('每年点赞量分析')
plt.ylabel('点赞量')
sns.despine(bottom=True)
plt.savefig('pic0.png',dpi=400)
plt.show()

#计算标题长度
data1['title_length'] = data1['标题'].apply(lambda x:len(x))
print('最大标题长度',round(data1['title_length'].max(),0))
print('最小标题长度',round(data1['title_length'].min(),0))
print('平均标题长度',round(data1['title_length'].mean(),0))

#计算Top20文章
data2 = data1.head(20)

fig = plt.figure(figsize=(15,8))
x = data2['标题'].tolist()
y = data2['点赞'].tolist()
sns.barplot(x, y, palette="coolwarm_r")
plt.title('Top20文章')
plt.ylabel('点赞量')
sns.despine(bottom=True)
pl.xticks(rotation=90)
plt.savefig('pic1.png',dpi=400)
plt.show()
data3 = data2[['标题','点赞','发文时间']]




#计算文章关键字
stop_list = pd.read_csv('./停用词.txt',engine='python',\
                        encoding='utf-8',names=['t'])['t'].tolist()
word_l = []
for line in data1['标题']:
    line_l = jieba.lcut(line)
    for word in line_l:
        if word not in stop_list and len(word)>1:
            word_l.append(word)
word_frame = pd.DataFrame()
word_frame['word'] = word_l
word_frame['count'] = 1
word_frame = word_frame.groupby('word').sum()['count'].to_frame()
word_frame = word_frame.sort_values(by='count',ascending=False)

word_frame = word_frame.head(20)
fig = plt.figure(figsize=(15,8))
x = word_frame.index.tolist()
y = word_frame['count'].tolist()
sns.barplot(x, y, palette="BuPu_r")
plt.title('词频Top20')
plt.ylabel('count')
sns.despine(bottom=True)
plt.savefig('./词频统计.png',dpi=400)
plt.show() 








